import FirstSection from "./FirstSection";

function Home() {
    return (<div>
        <FirstSection/>
    </div>)
}

export default Home;
