import React from 'react';
import Navbar from "../../components/navbar";
import FirstSection from "./FirstSection";

function WebDevelopment() {
    return (
        <div>
            <Navbar/>
            <FirstSection/>
        </div>
    );
}

export default WebDevelopment;
